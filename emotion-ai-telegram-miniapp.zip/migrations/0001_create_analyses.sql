CREATE TABLE IF NOT EXISTS analyses (id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_user_id TEXT NOT NULL, username TEXT, dominant_emotion TEXT NOT NULL, percentages_json TEXT NOT NULL, file_name TEXT, file_size INTEGER, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_analyses_user_created ON analyses (telegram_user_id, created_at DESC);
